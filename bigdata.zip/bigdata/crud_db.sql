-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 11 Okt 2018 pada 03.42
-- Versi Server: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crud_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `Nomor` int(11) NOT NULL AUTO_INCREMENT,
  `jurnal_name` varchar(200) DEFAULT NULL,
  `jurnal_instance` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Nomor`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `product`
--

INSERT INTO `product` (`Nomor`, `jurnal_name`, `jurnal_instance`) VALUES
(1, 'Analisis Jaringan Syaraf Tiruan untuk prediksi volume ekspor dan impor migas di Indonesia', 'STIKOM Tunas Bangsa Pematangsiantar Sumatera Utara'),
(2, 'Perancangan Sistem Pendukung Keputusan Pemilihan Pelanggan Terbaik Menggunakan Metode Simple Additive Weighting (SAW) Pada Bravo Supermarket Jombang', 'Universitas Pesantren Tinggi Darul Ulum (Unipdu) Jombang'),
(3, 'Konstruksi Forecasting System Multi-Model untuk pemodelan matematika pada peramalan Indeks Pembangunan Manusia Provinsi Nusa Tenggara Barat', 'Universitas Islam Negeri Mataram'),
(4, 'Evaluasi tingkat kebergunaan aplikasi Administrasi Penduduk menggunakan teknik System Usability Scale', 'Universitas Bina Darma, Palembang'),
(5, 'Permasalahan Implementasi Sistem Informasi Di Perguruan Tinggi Swasta', 'Universitas Pesentren Tinggi Darul Ulum (Unipdu) Jombang');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
